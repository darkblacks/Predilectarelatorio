@echo off
copy /Y "src\slides\SlideResultado.tsx" "%cd%\src\slides\SlideResultado.tsx"
echo SlideResultado.tsx atualizado.
pause
